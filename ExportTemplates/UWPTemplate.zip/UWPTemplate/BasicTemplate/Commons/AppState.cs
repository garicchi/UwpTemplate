﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Commons
{
    //アプリの状態
    //モバイルと通常、ワイド状態を定義
    public enum AppState
    {
        Mobile, Normal, Wide
    }
}
